# nr-dashboard-hcl-gen

Generates HCL configuration for newrelic_one_dashboard resources from exported JSON documents.

## Usage

Exported JSON can be fed to the tool 

### Using stdin

```
```

### Using a file

```
```